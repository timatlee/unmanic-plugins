Resizes a video to a defined size.

Will not upscale.
